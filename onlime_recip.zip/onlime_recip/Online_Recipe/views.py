from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from .models import Recipe


def home_page(request):
    return render(request, template_name='home.html')




def register_page(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')

        if password1 == password2:
            if User.objects.filter(username=username).exists():
                return render(request, template_name='register.html', context={'error': 'Username already exists'})
            else:
                user = User.objects.create_user(username=username, password=password1)
                user.save()
                return redirect('login')

    return render(request, template_name='register.html')


def login_page(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password1 = request.POST.get('password1')
        user = authenticate(username=username, password=password1)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return render(request, template_name='login.html', context={'error': 'Invalid username or password'})
    return render(request, 'login.html')


def user_logout(request):
    logout(request)
    return redirect('login')



def detail(request, page_id):
    recipe = Recipe.objects.get(id=page_id)
    context = {"recipe": recipe}
    return render(request, 'detail.html', context=context)

def create_page(request):

    if request.method == 'POST':
        title = request.POST.get('title')
        context = request.POST.get('context')

        Recipe.objects.create(
            title=title,
            context=context,
            author=request.user
        )


    return render(request, template_name='create.html')